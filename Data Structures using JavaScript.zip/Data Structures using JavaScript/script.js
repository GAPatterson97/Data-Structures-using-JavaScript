// Reference the <video> and the <source> elements
const video = document.getElementById('video'); 
const videoSource = document.getElementById('video-src')

// Reference other DOM elements
const videoList = document.getElementById("video-list");
const searchInput = document.getElementById('search-input');

// Create a copy of the original video playlist
const originalList = [...videos];

// Initialize variables to track the current video index and shuffle state
let currentvideoIndex = 0;
let isShuffle = false;
// New playlist created after filtered search flag
let isNewPlaylist = false;
let filteredvideos = originalList;

// Function to update the video playlist displayed in the UI
function updatePlayList(playlist){
    videoList.innerHTML = '';
    // Iterate through each video in the playlist and create list elements
    playlist.forEach(videos => {
        let liElement = document.createElement("li");
        liElement.innerHTML = `${Object.values(videos)[0]}`; // Display video title
        videoList.appendChild(liElement);
    });
}

// Function to update the UI with video information
function updateUI(currentvideoIndex, playlist) {
    document.getElementById('video-title').textContent = playlist[currentvideoIndex]["title"];
    document.getElementById('video-artist').textContent = playlist[currentvideoIndex]["artist-name"];
}

// Function to play the current video
function playvideo(playlist) {
    video.pause();
    // Set the video source
    videoSource.src = playlist[currentvideoIndex]["url"];    
    // Load and play the video after setting the source
    video.load();
    video.play();
    // Update the UI with video information
    updateUI(currentvideoIndex, playlist);
}

// Event delegation for video selection in the playlist
videoList.addEventListener('click', (e) => {
    if (e.target.tagName === 'LI') {
        currentvideoIndex = [...videoList.children].indexOf(e.target); // Get the index of the clicked video
        if (isNewPlaylist){
            playvideo(filteredvideos);
        } else if (isShuffle) {
            playvideo(videos);
        } else {
            playvideo(originalList);
        };
        //playvideo(isShuffle ? videos : originalList); // Play the selected video
    }
});

// Event listeners for play, next, and previous buttons
document.getElementById('play-button').addEventListener('click', () => {
    if (isNewPlaylist){
        playvideo(filteredvideos);
    } else if (isShuffle) {
        playvideo(videos);
    } else {
        playvideo(originalList);
    };
    //playvideo(isShuffle ? videos : originalList);
});

document.getElementById('next-button').addEventListener('click', () => {
    if (isNewPlaylist){
        // Move to the next video and play it
        currentvideoIndex = (currentvideoIndex + 1) % filteredvideos.length; 
        playvideo(filteredvideos);
    } else if (isShuffle) {
        // Move to the next video and play it
        currentvideoIndex = (currentvideoIndex + 1) % videos.length;
        playvideo(videos);
    } else {
        // Move to the next video and play it
        currentvideoIndex = (currentvideoIndex + 1) % originalList.length;
        playvideo(originalList);
    };
});

document.getElementById('prev-button').addEventListener('click', () => {
    // Move to the previous video and play it
    currentvideoIndex = (currentvideoIndex - 1 + videos.length) % videos.length;  
    if (isNewPlaylist){
        // Move to the next video and play it
        currentvideoIndex = (currentvideoIndex - 1 + filteredvideos.length) % filteredvideos.length; 
        playvideo(filteredvideos);
    } else if (isShuffle) {
        // Move to the next video and play it
        currentvideoIndex = (currentvideoIndex - 1 + videos.length) % videos.length;
        playvideo(videos);
    } else {
        // Move to the next video and play it
        currentvideoIndex = (currentvideoIndex - 1 + originalList.length) % originalList.length;
        playvideo(originalList);
    };
});

// Function to shuffle the array in place
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]]; // Swap elements to shuffle the array
    }
}

// Event listener for the Shuffle button
document.getElementById('shuffle-button').addEventListener('click', (event) => {
    isShuffle = !isShuffle;

    if (isShuffle) {
        event.target.textContent = "Click to Unshuffle";
        // Shuffle the playlist, update it, and play the first video
        shuffleArray(videos);
        updatePlayList(videos);
        currentvideoIndex = 0;
        playvideo(videos);
    } else {
        event.target.textContent = "Click to Shuffle";
        // Restore the original playlist, update it, and play the first video
        updatePlayList(originalList);
        currentvideoIndex = 0;
        playvideo(originalList);
    }
});

// Event listener to filter the playlist based on search input
searchInput.addEventListener('input', () => {
    const searchTerm = searchInput.value.toLowerCase();
    filteredvideos = originalList.filter((videos) =>
        videos.title.toLowerCase().includes(searchTerm)
    );
    // Update the displayed playlist with the filtered videos
    updatePlayList(filteredvideos);
    updateUI(currentvideoIndex, filteredvideos);
    if (searchTerm != "") {
        isNewPlaylist = true;
        if(isShuffle) {
            shuffleArray(filteredvideos);
        }
    } else {
        isNewPlaylist = false;
    }
    console.log(isNewPlaylist);
    console.log(searchTerm);
});

// Initialize the playlist and UI with the original list
updatePlayList(originalList);
updateUI(currentvideoIndex, originalList);